# LoginApp — Panduan Lengkap

Isi paket:
- `LoginApp/`  : project Android Studio (Kotlin, XML, Retrofit, SharedPreferences)
- `login_api/` : backend PHP REST API + `database.sql`

> Status build: source code ini belum dikompilasi menjadi APK oleh pembuatnya (tidak ada Android SDK/Gradle di lingkungan pembuatan). Build APK dilakukan di Android Studio Anda dengan langkah di bawah.

## 1. Backend (XAMPP)
1. Install XAMPP, buka XAMPP Control Panel, **Start Apache** dan **Start MySQL**.
2. Salin folder `login_api` ke `C:\xampp\htdocs\login_api` (macOS/Linux: `/opt/lampp/htdocs/login_api`).
3. Buka http://localhost/phpmyadmin → tab **Import** → pilih `login_api/database.sql` → **Go**.
   (Membuat database `login_android` dengan tabel `users` dan `auth_tokens`.)
4. Jika user/password MySQL Anda bukan `root` / kosong, ubah di `login_api/config.php`.
5. Uji cepat (PowerShell/terminal):
   ```
   curl -X POST http://localhost/login_api/register.php -H "Content-Type: application/json" -d "{\"nama\":\"Budi\",\"email\":\"budi@mail.com\",\"password\":\"rahasia123\",\"confirm_password\":\"rahasia123\"}"
   ```
   Respons berhasil: `{"success":true,"message":"Registrasi berhasil...","data":null}`

Endpoint: `POST register.php`, `POST login.php` (mengembalikan token), `GET profile.php` dan `POST logout.php` (header `Authorization: Bearer <token>`).
Keamanan: prepared statements, `password_hash/verify`, token acak 64 hex (di database hanya hash SHA-256), masa berlaku 7 hari, validasi di server.

## 2. Mengubah URL API
Buka `LoginApp/gradle.properties`, ubah satu baris:
```
API_BASE_URL=http://10.0.2.2/login_api/
```
- Emulator Android: `http://10.0.2.2/login_api/`
- HP fisik (satu WiFi dengan PC): `http://IP_PC_ANDA/login_api/` (cek dengan `ipconfig` / `ifconfig`, mis. 192.168.1.5)
- Produksi: `https://domain-anda.com/login_api/`

Setelah mengubah, **Sync Gradle** lalu build ulang. Untuk HTTP (non-HTTPS) ke IP lokal, tambahkan IP tersebut di
`app/src/main/res/xml/network_security_config.xml` (cleartext hanya diizinkan untuk host yang terdaftar, tidak global).
Hapus entri itu dan gunakan HTTPS untuk produksi.

HP fisik: pastikan Windows Firewall mengizinkan Apache (port 80) pada jaringan privat, dan HP + PC satu WiFi.

## 3. Build APK
1. Install **Android Studio** (Koala atau lebih baru, memakai JDK 17).
2. **File → Open** → pilih folder `LoginApp`. Tunggu Gradle sync (butuh internet; SDK 34 akan diunduh bila diminta).
3. **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. APK ada di `LoginApp/app/build/outputs/apk/debug/app-debug.apk`.
   (Via terminal setelah wrapper dibuat Android Studio: `./gradlew assembleDebug`)
5. Instal: aktifkan *Opsi Pengembang → USB debugging*, sambungkan HP lalu klik **Run ▶**; atau salin `app-debug.apk` ke HP dan buka (izinkan "Install unknown apps").

APK rilis: **Build → Generate Signed App Bundle / APK** → APK → buat keystore → pilih `release`.

## 4. Mengatasi error umum
| Masalah | Solusi |
|---|---|
| "Tidak dapat terhubung ke server" | Apache belum jalan, URL/IP salah, firewall, atau HP beda jaringan. Buka URL `.../login_api/login.php` di browser HP untuk menguji. |
| `Cleartext HTTP traffic not permitted` | Host belum ada di `network_security_config.xml`. |
| "Database tidak tersedia" | MySQL belum jalan / `database.sql` belum diimpor / kredensial di `config.php` salah. |
| Sesi selalu "tidak valid" | Pastikan `.htaccess` ikut tersalin dan `mod_rewrite` aktif di Apache. |
| Gradle sync gagal | Cek internet, gunakan JDK 17 (File → Settings → Build Tools → Gradle → Gradle JDK). |
| `SDK location not found` | Biarkan Android Studio membuat `local.properties`, atau set `sdk.dir`. |
| Template gradlew tidak ada | Normal; Android Studio memakai `gradle-wrapper.properties`. Buat wrapper via *File → Sync* atau `gradle wrapper`. |

## 5. Daftar uji manual
Splash → Register → cek data di phpMyAdmin → Login benar → Login salah ditolak → Dashboard menampilkan nama/email
→ tutup & buka ulang app (masuk langsung ke Dashboard) → Logout kembali ke Login → matikan WiFi lalu Login (muncul pesan, tidak crash) → Register email sama (ditolak) → password < 8 karakter (ditolak).
