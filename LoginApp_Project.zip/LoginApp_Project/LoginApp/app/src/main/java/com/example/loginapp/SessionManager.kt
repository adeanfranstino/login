package com.example.loginapp

import android.content.Context

/** Menyimpan sesi login lokal. allowBackup=false di manifest agar token tidak ikut ter-backup. */
class SessionManager(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("login_session", Context.MODE_PRIVATE)

    fun save(token: String, user: User) {
        prefs.edit()
            .putString("token", token)
            .putInt("id", user.id)
            .putString("nama", user.nama)
            .putString("email", user.email)
            .putString("created_at", user.createdAt)
            .apply()
    }

    fun updateUser(user: User) {
        prefs.edit()
            .putInt("id", user.id).putString("nama", user.nama)
            .putString("email", user.email).putString("created_at", user.createdAt).apply()
    }

    val token: String? get() = prefs.getString("token", null)
    val userId: Int get() = prefs.getInt("id", 0)
    val name: String get() = prefs.getString("nama", "") ?: ""
    val email: String get() = prefs.getString("email", "") ?: ""
    val createdAt: String? get() = prefs.getString("created_at", null)

    fun isLoggedIn(): Boolean = !token.isNullOrEmpty()
    fun clear() = prefs.edit().clear().apply()
}
