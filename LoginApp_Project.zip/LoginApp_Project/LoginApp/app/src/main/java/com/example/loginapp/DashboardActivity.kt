package com.example.loginapp

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.GridLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.loginapp.databinding.ActivityDashboardBinding
import com.example.loginapp.databinding.ItemMenuBinding
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class DashboardActivity : AppCompatActivity() {
    private lateinit var b: ActivityDashboardBinding
    private lateinit var session: SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        session = SessionManager(this)
        if (!session.isLoggedIn()) { goToLogin(); return }

        b = ActivityDashboardBinding.inflate(layoutInflater)
        setContentView(b.root)

        buildMenu()
        render()
        b.btnLogout.setOnClickListener { logout() }
        loadProfile()
    }

    private fun render() {
        val nama = session.name
        b.tvGreeting.text = greeting()
        b.tvHeaderName.text = nama
        b.tvName.text = nama
        b.tvEmail.text = session.email
        b.tvAvatar.text = nama.trim().firstOrNull()?.uppercase() ?: "?"
        b.tvUserId.text = "ID Akun      : #${session.userId}"
        b.tvSince.text = "Bergabung    : ${formatDate(session.createdAt)}"
        b.tvStatus.text = "Status         : Aktif"
    }

    private fun greeting(): String = when (Calendar.getInstance().get(Calendar.HOUR_OF_DAY)) {
        in 4..10 -> "Selamat pagi,"
        in 11..14 -> "Selamat siang,"
        in 15..17 -> "Selamat sore,"
        else -> "Selamat malam,"
    }

    private fun formatDate(raw: String?): String = try {
        val d = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).parse(raw ?: "")!!
        SimpleDateFormat("d MMMM yyyy", Locale("id", "ID")).format(d)
    } catch (e: Exception) { raw ?: "-" }

    private fun buildMenu() {
        val items = listOf(
            "Profil" to R.drawable.ic_person,
            "Keamanan" to R.drawable.ic_lock,
            "Pengaturan" to R.drawable.ic_settings,
            "Bantuan" to R.drawable.ic_help
        )
        items.forEach { (label, icon) ->
            val m = ItemMenuBinding.inflate(LayoutInflater.from(this), b.gridMenu, false)
            m.tvLabel.text = label
            m.ivIcon.setImageResource(icon)
            m.root.layoutParams = GridLayout.LayoutParams(
                GridLayout.spec(GridLayout.UNDEFINED, 1f), GridLayout.spec(GridLayout.UNDEFINED, 1f)
            ).apply { width = 0; setMargins(12, 12, 12, 12) }
            m.root.setOnClickListener {
                Toast.makeText(this, "Menu $label akan segera tersedia", Toast.LENGTH_SHORT).show()
            }
            b.gridMenu.addView(m.root)
        }
    }

    private fun loadProfile() {
        val token = session.token ?: return
        lifecycleScope.launch {
            val res = apiCall { ApiClient.api.profile("Bearer $token") }
            val user = res.data?.user
            when {
                res.success && user != null -> { session.updateUser(user); render() }
                res.httpCode == 401 -> {
                    Toast.makeText(this@DashboardActivity, res.message, Toast.LENGTH_LONG).show()
                    session.clear(); goToLogin()
                }
                else -> Toast.makeText(this@DashboardActivity, res.message, Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun logout() {
        val token = session.token
        b.btnLogout.isEnabled = false
        lifecycleScope.launch {
            if (token != null) apiCall { ApiClient.api.logout("Bearer $token") } // best effort, tetap logout lokal
            session.clear()
            goToLogin()
        }
    }

    private fun goToLogin() {
        startActivity(Intent(this, MainActivity::class.java))
        finishAffinity()
    }
}
