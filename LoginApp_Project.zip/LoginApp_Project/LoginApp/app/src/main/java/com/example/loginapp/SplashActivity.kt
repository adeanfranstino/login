package com.example.loginapp

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.loginapp.databinding.ActivitySplashBinding
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@SuppressLint("CustomSplashScreen")
class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val b = ActivitySplashBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.ivLogo.apply { alpha = 0f; scaleX = 0.6f; scaleY = 0.6f }
        b.ivLogo.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(700).start()
        listOf(b.tvName, b.tvTagline).forEach { it.alpha = 0f; it.animate().alpha(1f).setStartDelay(400).setDuration(600).start() }

        lifecycleScope.launch {
            delay(1800)
            val target = if (SessionManager(this@SplashActivity).isLoggedIn())
                DashboardActivity::class.java else MainActivity::class.java
            startActivity(Intent(this@SplashActivity, target))
            finish()
        }
    }
}
