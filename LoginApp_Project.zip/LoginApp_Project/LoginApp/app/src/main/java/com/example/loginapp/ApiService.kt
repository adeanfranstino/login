package com.example.loginapp

import com.google.gson.annotations.SerializedName
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST

data class RegisterRequest(
    val nama: String,
    val email: String,
    val password: String,
    @SerializedName("confirm_password") val confirmPassword: String
)

data class LoginRequest(val email: String, val password: String)

data class User(
    val id: Int,
    val nama: String,
    val email: String,
    @SerializedName("created_at") val createdAt: String?
)

data class AuthData(val token: String?, val user: User?)

data class ApiResponse<T>(
    val success: Boolean,
    val message: String,
    val data: T?,
    val httpCode: Int = 0
)

interface ApiService {
    @POST("register.php")
    suspend fun register(@Body body: RegisterRequest): Response<ApiResponse<AuthData>>

    @POST("login.php")
    suspend fun login(@Body body: LoginRequest): Response<ApiResponse<AuthData>>

    @GET("profile.php")
    suspend fun profile(@Header("Authorization") bearer: String): Response<ApiResponse<AuthData>>

    @POST("logout.php")
    suspend fun logout(@Header("Authorization") bearer: String): Response<ApiResponse<AuthData>>
}
