package com.example.loginapp

import com.google.gson.Gson
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.io.IOException
import java.util.concurrent.TimeUnit

object ApiClient {
    val api: ApiService by lazy {
        val logger = HttpLoggingInterceptor().apply {
            level = if (BuildConfig.DEBUG) HttpLoggingInterceptor.Level.BASIC else HttpLoggingInterceptor.Level.NONE
        }
        val client = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .addInterceptor(logger)
            .build()
        Retrofit.Builder()
            .baseUrl(BuildConfig.BASE_URL) // diatur lewat API_BASE_URL di gradle.properties
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiService::class.java)
    }
}

/** Membungkus pemanggilan API: tidak pernah melempar exception, sehingga aplikasi tidak crash saat offline. */
suspend fun <T> apiCall(block: suspend () -> Response<ApiResponse<T>>): ApiResponse<T> =
    try {
        val r = block()
        if (r.isSuccessful) {
            r.body()?.copy(httpCode = r.code()) ?: ApiResponse(false, "Respons server kosong", null, r.code())
        } else {
            val msg = try {
                Gson().fromJson(r.errorBody()?.string(), ApiResponse::class.java)?.message
            } catch (e: Exception) { null }
            ApiResponse(false, msg ?: "Kesalahan server (${r.code()})", null, r.code())
        }
    } catch (e: IOException) {
        ApiResponse(false, "Tidak dapat terhubung ke server. Periksa koneksi internet Anda.", null, -1)
    } catch (e: Exception) {
        ApiResponse(false, "Terjadi kesalahan: ${e.localizedMessage}", null, -2)
    }
