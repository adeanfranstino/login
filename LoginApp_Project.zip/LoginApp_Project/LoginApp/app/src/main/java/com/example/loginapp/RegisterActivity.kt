package com.example.loginapp

import android.os.Bundle
import android.util.Patterns
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.loginapp.databinding.ActivityRegisterBinding
import kotlinx.coroutines.launch

class RegisterActivity : AppCompatActivity() {
    private lateinit var b: ActivityRegisterBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.btnRegister.setOnClickListener { attemptRegister() }
        b.tvLogin.setOnClickListener { finish() }
    }

    private fun attemptRegister() {
        val nama = b.etNama.text.toString().trim()
        val email = b.etEmail.text.toString().trim()
        val pass = b.etPassword.text.toString()
        val confirm = b.etConfirm.text.toString()
        listOf(b.tilNama, b.tilEmail, b.tilPassword, b.tilConfirm).forEach { it.error = null }

        var ok = true
        if (nama.isEmpty()) { b.tilNama.error = "Nama lengkap wajib diisi"; ok = false }
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) { b.tilEmail.error = "Format email tidak valid"; ok = false }
        if (pass.length < 8) { b.tilPassword.error = "Password minimal 8 karakter"; ok = false }
        if (confirm != pass) { b.tilConfirm.error = "Konfirmasi password tidak sama"; ok = false }
        if (!ok) return

        setLoading(true)
        lifecycleScope.launch {
            val res = apiCall { ApiClient.api.register(RegisterRequest(nama, email, pass, confirm)) }
            setLoading(false)
            if (res.success) {
                Toast.makeText(this@RegisterActivity, "Registrasi berhasil. Silakan login.", Toast.LENGTH_LONG).show()
                finish()
            } else {
                if (res.httpCode == 409) b.tilEmail.error = res.message
                Toast.makeText(this@RegisterActivity, res.message, Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun setLoading(loading: Boolean) {
        b.progress.visibility = if (loading) View.VISIBLE else View.GONE
        b.btnRegister.isEnabled = !loading
    }
}
