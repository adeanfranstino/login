package com.example.loginapp

import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.loginapp.databinding.ActivityMainBinding
import kotlinx.coroutines.launch

/** Halaman Login. */
class MainActivity : AppCompatActivity() {
    private lateinit var b: ActivityMainBinding
    private lateinit var session: SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        session = SessionManager(this)

        b.btnLogin.setOnClickListener { attemptLogin() }
        b.tvRegister.setOnClickListener { startActivity(Intent(this, RegisterActivity::class.java)) }
    }

    private fun attemptLogin() {
        val email = b.etEmail.text.toString().trim()
        val pass = b.etPassword.text.toString()
        b.tilEmail.error = null
        b.tilPassword.error = null

        var ok = true
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) { b.tilEmail.error = "Format email tidak valid"; ok = false }
        if (pass.isEmpty()) { b.tilPassword.error = "Password wajib diisi"; ok = false }
        if (!ok) return

        setLoading(true)
        lifecycleScope.launch {
            val res = apiCall { ApiClient.api.login(LoginRequest(email, pass)) }
            setLoading(false)
            val token = res.data?.token
            val user = res.data?.user
            if (res.success && token != null && user != null) {
                session.save(token, user)
                startActivity(Intent(this@MainActivity, DashboardActivity::class.java))
                finishAffinity()
            } else {
                Toast.makeText(this@MainActivity, res.message, Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun setLoading(loading: Boolean) {
        b.progress.visibility = if (loading) android.view.View.VISIBLE else android.view.View.GONE
        b.btnLogin.isEnabled = !loading
    }
}
