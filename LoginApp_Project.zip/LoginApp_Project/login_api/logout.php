<?php
require __DIR__ . '/config.php';
require_method('POST');
try {
    $token = bearer_token();
    if ($token) {
        $hash = hash('sha256', $token);
        $s = db()->prepare('DELETE FROM auth_tokens WHERE token_hash = ?');
        $s->bind_param('s', $hash);
        $s->execute();
    }
    respond(true, 'Logout berhasil');
} catch (mysqli_sql_exception $e) {
    respond(false, 'Terjadi kesalahan pada server', null, 500);
}
