<?php
require __DIR__ . '/config.php';
require_method('POST');
$in = json_input();
$nama  = trim((string)($in['nama'] ?? ''));
$email = strtolower(trim((string)($in['email'] ?? '')));
$pass  = (string)($in['password'] ?? '');
$conf  = (string)($in['confirm_password'] ?? '');

if ($nama === '' || mb_strlen($nama) > 100) respond(false, 'Nama lengkap wajib diisi (maks. 100 karakter)', null, 422);
if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 150) respond(false, 'Format email tidak valid', null, 422);
if (strlen($pass) < 8) respond(false, 'Password minimal 8 karakter', null, 422);
if ($pass !== $conf) respond(false, 'Konfirmasi password tidak sama', null, 422);

try {
    $db = db();
    $s = $db->prepare('SELECT id FROM users WHERE email = ?');
    $s->bind_param('s', $email);
    $s->execute();
    if ($s->get_result()->num_rows > 0) respond(false, 'Email sudah terdaftar', null, 409);

    $hash = password_hash($pass, PASSWORD_DEFAULT);
    $s = $db->prepare('INSERT INTO users (nama, email, password) VALUES (?, ?, ?)');
    $s->bind_param('sss', $nama, $email, $hash);
    $s->execute();
    respond(true, 'Registrasi berhasil. Silakan login.', null, 201);
} catch (mysqli_sql_exception $e) {
    if ((int)$e->getCode() === 1062) respond(false, 'Email sudah terdaftar', null, 409);
    respond(false, 'Terjadi kesalahan pada server', null, 500);
}
