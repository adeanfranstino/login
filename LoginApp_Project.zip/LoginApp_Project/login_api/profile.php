<?php
require __DIR__ . '/config.php';
require_method('GET');
try {
    $user = auth_user();
    respond(true, 'OK', ['user' => $user]);
} catch (mysqli_sql_exception $e) {
    respond(false, 'Terjadi kesalahan pada server', null, 500);
}
