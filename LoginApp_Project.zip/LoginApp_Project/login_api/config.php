<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');

// === Konfigurasi database (XAMPP default). Ubah untuk server produksi. ===
const DB_HOST = '127.0.0.1';
const DB_NAME = 'login_android';
const DB_USER = 'root';
const DB_PASS = '';
const TOKEN_TTL_DAYS = 7;

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

function respond(bool $success, string $message, $data = null, int $code = 200): void {
    http_response_code($code);
    echo json_encode(['success' => $success, 'message' => $message, 'data' => $data], JSON_UNESCAPED_UNICODE);
    exit;
}

function db(): mysqli {
    static $conn = null;
    if ($conn === null) {
        try {
            $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
            $conn->set_charset('utf8mb4');
        } catch (Throwable $e) {
            respond(false, 'Database tidak tersedia', null, 500);
        }
    }
    return $conn;
}

function require_method(string $method): void {
    if ($_SERVER['REQUEST_METHOD'] !== $method) respond(false, 'Metode tidak diizinkan', null, 405);
}

function json_input(): array {
    $d = json_decode(file_get_contents('php://input') ?: '', true);
    return is_array($d) ? $d : [];
}

function issue_token(int $userId): string {
    $token = bin2hex(random_bytes(32));
    $hash = hash('sha256', $token);
    $exp = date('Y-m-d H:i:s', time() + TOKEN_TTL_DAYS * 86400);
    $s = db()->prepare('INSERT INTO auth_tokens (user_id, token_hash, expires_at) VALUES (?, ?, ?)');
    $s->bind_param('iss', $userId, $hash, $exp);
    $s->execute();
    return $token;
}

function bearer_token(): ?string {
    $h = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';
    if ($h === '' && function_exists('getallheaders')) {
        foreach (getallheaders() as $k => $v) if (strtolower($k) === 'authorization') $h = $v;
    }
    return preg_match('/^Bearer\s+(\S+)$/i', $h, $m) ? $m[1] : null;
}

function auth_user(): array {
    $token = bearer_token();
    if (!$token) respond(false, 'Sesi tidak valid. Silakan login kembali.', null, 401);
    $hash = hash('sha256', $token);
    $s = db()->prepare('SELECT u.id, u.nama, u.email, u.created_at FROM auth_tokens t
                        JOIN users u ON u.id = t.user_id WHERE t.token_hash = ? AND t.expires_at > NOW()');
    $s->bind_param('s', $hash);
    $s->execute();
    $user = $s->get_result()->fetch_assoc();
    if (!$user) respond(false, 'Sesi berakhir. Silakan login kembali.', null, 401);
    $user['id'] = (int)$user['id'];
    return $user;
}
