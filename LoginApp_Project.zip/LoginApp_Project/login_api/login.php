<?php
require __DIR__ . '/config.php';
require_method('POST');
$in = json_input();
$email = strtolower(trim((string)($in['email'] ?? '')));
$pass  = (string)($in['password'] ?? '');

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) respond(false, 'Format email tidak valid', null, 422);
if ($pass === '') respond(false, 'Password wajib diisi', null, 422);

try {
    $db = db();
    $s = $db->prepare('SELECT id, nama, email, password, created_at FROM users WHERE email = ?');
    $s->bind_param('s', $email);
    $s->execute();
    $u = $s->get_result()->fetch_assoc();

    if (!$u || !password_verify($pass, $u['password'])) {
        respond(false, 'Email atau password salah', null, 401);
    }
    $db->query('DELETE FROM auth_tokens WHERE expires_at < NOW()');
    $token = issue_token((int)$u['id']);
    respond(true, 'Login berhasil', [
        'token' => $token,
        'user'  => ['id' => (int)$u['id'], 'nama' => $u['nama'], 'email' => $u['email'], 'created_at' => $u['created_at']],
    ]);
} catch (mysqli_sql_exception $e) {
    respond(false, 'Terjadi kesalahan pada server', null, 500);
}
